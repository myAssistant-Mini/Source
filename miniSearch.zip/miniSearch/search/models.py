from django.db import models

# Create your models here.
photo = models.ImageField(upload_to="gallery")